<?php
/**
* Module permettant d'exporter les commandes de cheminee-ethanol-bio.com wers wikao.fr
*/

if (!defined('_PS_VERSION_'))
  exit;
 
class orderExporter extends Module
{
	public function __construct()
	{
	$this->name = 'orderExporter';
	$this->tab = 'export';
	$this->version = '0.95.';
	$this->author = 'WIART Jean-Christophe';
	$this->need_instance = 0;
	$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_); 
	$this->bootstrap = true;
	include_once(dirname(__FILE__).'/classes/orderStateHandler.class.php');
	include_once(dirname(__FILE__).'/classes/apiXportKeyHandler.class.php');
	
	parent::__construct();
	
	$this->displayName = $this->l('Export orders.');
	$this->description = $this->l('Affords the user to export orders from ceb to wikao.');
	
	$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	
	if (!Configuration::get('ORDEREXPORT_NAME'))      
		$this->warning = $this->l('No name provided');
	}
	
	public function install() {
	if (Shop::isFeatureActive())
    	Shop::setContext(Shop::CONTEXT_ALL);
	if (parent::install() === false ||
		!Configuration::updateValue('ORDEREXPORT_NAME', 'Order exporter') ||
		!Configuration::updateValue('ORDEREXPORT_DISTANT_SITE_URL', '') ||
		!Configuration::updateValue('ORDEREXPORT_DISTANT_SITE_WK', '') ||
		$this->updateOrderState() === false
		)
		{
			return false;
		}
		else
		{
			if (Configuration::get('WISYNCH_SETMS') == 0){
				if ($this->updateOrderState() === false)
					return false;
			} else {
				return true;
			}
		}
	}
	
	public function uninstall() {
		if (parent::uninstall() === false ||
		$this->resetOrderState() === false
		)
			return false;
		return true;
	}
	
	protected function updateOrderState() {
		$alterTable = "
			ALTER TABLE `"._DB_PREFIX_."order_state`
			ADD (is_default_order_export BOOLEAN NOT NULL DEFAULT FALSE)";
	
		return DB::getInstance()->Execute($alterTable);	
	}
	
	protected function resetOrderState() {
		$alterTable = "
			ALTER TABLE `"._DB_PREFIX_."order_state`
			DROP COLUMN is_default_order_export";
	
		return DB::getInstance()->Execute($alterTable);		
	}
	
	public function getContent() {
		
		$output = null;
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
		$default_shop = (int)Configuration::get('PS_SHOP_DEFAULT');
		
		if (Tools::isSubmit('formSetDefaultOStatus'))
		{
			$root = 'available_os_';
			$orderState = new OrderStateToExport();
			$available_order_state = $orderState->getOrderStates();
			$order_state_to_update = array();
			
			foreach ($available_order_state as $order_state) {
				$optionToCheck = Tools::getValue($root . $order_state['id_order_state']);
				if ($optionToCheck=='on') {
					array_push($order_state_to_update, (int)$order_state['id_order_state']);
				}
				
			}	
			$available_order_state = $orderState->updateDefaultOrderState($order_state_to_update, $default_lang);
		}
		
		if (Tools::isSubmit('formDistantSite'))
		{
			$url = Tools::getValue('DISTANT_SITE_URL');
			$webserviceKey = Tools::getValue('DISTANT_SITE_WK');
			$distantSite = new apiXportKeyHandler();
			
			if($addSite = $distantSite->updateApi($url, $webserviceKey))
			{
				$output = $this->displayConfirmation($this->l('Settings updated for ' . Tools::getValue('DISTANT_SITE_URL')));	
			}
		}
		
		return $output.$this->displayForm();
	}
	
	public function displayForm() {
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
		
		$orderState = new OrderStateToExport();
		$availablesOrderStates = $orderState->getOrderStates();
		$orderStates = array();
		
		foreach ($availablesOrderStates as $state)
		{
		  $orderStates[] = array(
			"id" => (int)$state['id_order_state'],
			"name" => $state['name']
		  );
		}
		
		if(Configuration::get('WISYNCH_SETMS') == 0)
		{
			$fields_form[0]['form'] = array(
				'legend' => array(
					'title' => $this->l('Set default order states for current site'),
					'icon' => 'icon-cogs'
				),
				'input' => array(
					array(
					  'type' => 'checkbox',                              // This is a <select> tag.
					  'label' => $this->l('Default order states:'),         // The <label> for this <select> tag.
					  'name' => 'available_os',                     // The content of the 'id' attribute of the <select> tag.
					  'required' => true,                              // If set to true, this orderToGetion must be set.
					  'values' => array(
						'query' => $orderStates,                           // $orderStates contains the data itself.
						'id' => 'id',                        // The value of the 'id' key must be the same as the key for 'value' attribute of the <orderToGetion> tag in each $orderStates sub-array.
						'name' => 'name',                             // The value of the 'name' key must be the same as the key for the text content of the <orderToGetion> tag in each $orderStates sub-array.
					  )
					)
				 ),
				'submit' => array(
					'title' => $this->l('Save'),
					'class' => 'button',
					'name' => 'formSetDefaultOStatus'
				)
			);
		}
		else
		{
		$fields_form[0]['form'] = array(
				'legend' => array(
					'title' => $this->l('Webservices settings for cheminee-ethanol-bio.com'),
					'icon' => 'icon-cogs'
					),
				'input' => array(
					array(
						'type' => 'text',
						'label' => $this->l('Distant site URL'),
						'name' => 'DISTANT_SITE_URL',
					),
					array(
						'type' => 'text',
						'label' => $this->l('Distant site Webservice key #'),
						'name' => 'DISTANT_SITE_WK',
					)
				),
				'submit' => array(
					'title' => $this->l('Save'),
					'class' => 'button',
					'name' => 'formDistantSite'
				)
			);	
		}
		
		$helper = new HelperForm();
		 
		// Module, token et currentIndex
		$helper->module = $this;
		$helper->name_controller = $this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
		 
		// Langue
		$helper->default_form_language = $default_lang;
		$helper->allow_employee_form_lang = $default_lang;
		 
		// Titre, barre d'outils
		$helper->title = $this->displayName;
		$helper->show_toolbar = true;        // false -> remove toolbar
		$helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
		$helper->submit_action = 'submit'.$this->name;
		$helper->toolbar_btn = array(
			'save' =>
			array(
				'desc' => $this->l('Save'),
				'href' => AdminController::$currentIndex.'&save'.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),
			),
			'back' => array(
				'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
				'desc' => $this->l('Back to list')
			)
		);
		
		//Initialisation des formulaires.
		foreach ($availablesOrderStates as $state)
		{
			if ($state['is_default_order_export'])
			{
				$helper->fields_value['available_os_' . (int)$state['id_order_state']] = true;
			}
		} 

		$helper->fields_value['DISTANT_SITE_URL'] = Configuration::get('ORDEREXPORT_DISTANT_SITE_URL');
		$helper->fields_value['DISTANT_SITE_WK'] = Configuration::get('ORDEREXPORT_DISTANT_SITE_WK');
		
		return $helper->generateForm($fields_form);
	}
}