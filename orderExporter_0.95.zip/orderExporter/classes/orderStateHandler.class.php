<?php
/*
* Cette classe permet de manipuler la table des états de commande.
*/

class OrderStateToExport {
	
	private $_name = 'orderlistExportOrderState';
	
	public function __construct()
	{
	}
	
	// Identifier les commandes valides pour l'export.
	public function getOrderStates() {
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
		$sql = "SELECT osl.id_order_state, osl.name, os.is_default_order_export
				FROM `"._DB_PREFIX_."order_state_lang` osl
				INNER JOIN `"._DB_PREFIX_."order_state` os ON (osl.id_order_state = os.id_order_state)
				WHERE osl.id_lang = ". $default_lang . "
		";	
		
		return DB::getInstance()->ExecuteS($sql);
	}
	
	// Update de la table de états de commande (valeurs par défaut).
	public function updateDefaultOrderState($order_state_to_update, $default_lang)
	{
		$resetDefaultOS = $this->getOrderStates();
		foreach ($resetDefaultOS as $g)
		{
			Db::getInstance()->update($table = 'order_state', 
									  $data = array('is_default_order_export' => false),
									  $limit = 0, 
									  $null_values = false, 
									  $use_cache = true, 
									  $add_prefix = true);
		}
		
		foreach($order_state_to_update as $h)
		{
			Db::getInstance()->update($table = 'order_state', 
									  $data = array('is_default_order_export' => true),
									  $where = 'id_order_state = ' . $h, 
									  $limit = 0, 
									  $null_values = false, 
									  $use_cache = true, 
									  $add_prefix = true);
		}
		return true;
	}
	
	// Update des valeurs de l'API du site distant
	public function updateApi($distantUrl, $webserviceKey) {
		Configuration::updateValue('ORDEREXPORT_DISTANT_SITE_URL', $distantUrl);
		Configuration::updateValue('ORDEREXPORT_DISTANT_SITE_WK', $webserviceKey);
	}
}