<?php
/*
* Cette classe permet de récupérer pour le site en cours, l'ensemble des états de commande définit comme étant par défaut et donc disponible pour l'export.
*/

class apiXportKeyHandler {
	
	private $_name = 'apiXportKeyHandler';
	
	public function __construct()
	{
	}
	
	// Update des valeurs de l'API du site distant
	public function updateApi($distantUrl, $webserviceKey) {
		Configuration::updateValue('ORDEREXPORT_DISTANT_SITE_URL', $distantUrl);
		Configuration::updateValue('ORDEREXPORT_DISTANT_SITE_WK', $webserviceKey);
	}
	
}